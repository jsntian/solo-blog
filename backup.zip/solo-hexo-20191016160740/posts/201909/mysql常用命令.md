title: mysql常用命令
date: '2019-09-21 16:05:31'
updated: '2019-09-21 16:11:10'
tags: [mysql]
permalink: /articles/2019/09/21/1569053131380.html
---
## 创建库
```
create database test default character set utf8mb4 collate utf8mb4_general_ci;
```
## 创建用户并对test库授权
```
create user test@'%' identified by '123456';
grant all privileges on test.* to test;
flush privileges;
```
## 登录
```
mysql -uroot -p123456
mysql -h xx.xx.xx.xx -utest -p123456 -D test

```
