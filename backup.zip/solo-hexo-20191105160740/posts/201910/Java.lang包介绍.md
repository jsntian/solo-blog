title: ' Java.lang包介绍'
date: '2019-10-10 16:37:13'
updated: '2019-10-10 16:37:13'
tags: [Java核心要义]
permalink: /articles/2019/10/10/1570696633205.html
---
1. java、javax和org。其中以java开头的包名是JDK的基础语言包，以javax开头的属

- 于JDK扩展包(其中x是extend的简写)，而以org开头的则是第三方组织提供的功能包

* (org是organization的简写)。而在JDK API中还包含了一些以com.sun开头的包名

+ 这些是SUN公司提供的一些功能包，由于这些包中的类随着JDK版本的更改变化很大不具备兼容性，所以未在标准的JDK API文档中进行公开

2.在本章接下来的内容中，首先介绍常用的类的功能以及基本使用，这                 些介绍主要涵盖java.lang包和java.util包中的内容

+  java.lang包  
java.lang包是Java基础语言包(其中lang是language(语言)的简写)，该包中包含

- Java语言所需要的基本的功能类、接口等信息，是进行Java语言编程的基础。

* 由于在进行Java语言编程时，该包的使用特别频繁，所以在Java语言中，该包是被默认引入的

