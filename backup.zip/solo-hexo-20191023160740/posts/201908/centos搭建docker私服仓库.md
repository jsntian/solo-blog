title: centos搭建docker私服仓库
date: '2019-08-31 14:36:25'
updated: '2019-08-31 18:55:49'
tags: [docker]
permalink: /articles/2019/08/31/1567233385867.html
---
## 安装docker
```
yum -y install docker-io
# 启动
systemctl restart docker
```
## 镜像命令
### 1. docker images

* 查看本地已经拥有的镜像

### 2. docker pull 镜像名

* 下载镜像

### 3. docker rmi 镜像id/镜像名

* 删除镜像(多个)

### 4. docker commit

* 用运行的容器创建镜像
* 参数: -a 作者 -m '注解' 容器名(id) 镜像名:镜像版本号

### 5. docker push 镜像名:镜像版本号

* 上传镜像
## 三 容器命令

### 1. docker ps

查看运行中的容器

### 2. docker ps -a

查看所有容器

### 3. docker rm 容器id

删除容器

### 4. docker stop 容器id

停止容器

### 5. docker start 容器id

启动容器

### 6. docker restart 容器id

重启容器

### 7. docker run

创建并启动容器

* -it 启动交互终端(结尾需要驾驶 /bin/bash)
* -d 后台启动
* -p 80:8080 端口映射80为宿主端口,8080为容器端口  
    ​ -- name=blog 容器命名

### 8. control+p+q

退出容器并保持容器运行(终止容器退出命令为exit)

### 9. docker exec -it 容器名或者容器的id /bin/bash

进入正在运行的容器

### 10. docker cp

* 宿主机到容器

```
# 将主机/www/abc目录拷贝到容器xxxxx中，目录重命名为www。
docker cp /www/abc xxxxx:/www

```

* 容器到宿主机

```
# 将容器xxxxxx的/www目录拷贝到主机的/tmp目录中。
docker cp  xxxxx:/www /tmp/

```
## dockerHUB私服

### 1. 搭建registry

```
# 拉取registry
docker pull registry

cd /opt/
mkdir auth
docker run --entrypoint htpasswd registry:2 -Bbn test 123456 > auth/htpasswd

# 创建启动 qdockerhub容器
docker run -d -v /data/registry:/var/lib/registry -v /opt/auth:/auth -p 5000:5000 --restart=always --name mydockerhub -e "REGISTRY_AUTH=htpasswd" -e "REGISTRY_AUTH_HTPASSWD_REALM=Registry Realm" -e REGISTRY_AUTH_HTPASSWD_PATH=/auth/htpasswd registry:latest

#参数注解：
1. run：启动
2. -d： 后台运行
3. -p 5000:5000 宿主机5000端口映射到容器5000端口（registry仓库默认开启5000端口）
4. --name myregistry 容器重命名
5. --restart=always 重启设置6. registry[:tag] 需要启动到仓库名称（不添加tag，默认拉取最新版:latest）
6. -v /data/registry:/var/lib/registry 将主机当前目录下的 /data/registry 目录挂载到容器的 /var/lib/registry

docker  login 127.0.0.1:5000

# 测试/v2/_catalog接口
curl http://127.0.0.1:5000/v2/_catalog
{"repositories":[]}

```
### 2. 配置私有仓库地址,搭建docker集群需要给每台docker环境进行如下操作
```
mkdir -p /etc/docker 
touch /etc/docker/daemon.json
sudo  echo -e '{"insecure-registries":["xxx.xxx.xxx.xxx:5000"]}' >> /etc/docker/daemon.json
```
### 3. 重启docker容器，查看registry是否添加
```
systemctl daemon-reload  #重载docker配置
systemctl restart docker    #重启docker服务
docker info #查看docker信息确认仓库是否添加
``` 　　
### 4. 开启远程调用（这里是为了后期使用maven插件生成docker镜像）

```
vim /usr/lib/systemd/system/docker.service
ExecStart=/usr/bin/dockerd -H tcp://0.0.0.0:2375 -H unix://var/run/docker.sock
```
