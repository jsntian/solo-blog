title: flink从0到1(一)
date: '2019-08-28 10:47:08'
updated: '2019-08-28 10:51:32'
tags: [flink]
permalink: /articles/2019/08/28/1566960428227.html
---
# 相关地址
flink地址： ``https://github.com/apache/flink.git``
flink地址： ``https://github.com/apache/flink/tree/blink``
文档：[Apache Flink 文档](https://ci.apache.org/projects/flink/flink-docs-release-1.9/zh/)  
[本地安装教程](https://ci.apache.org/projects/flink/flink-docs-master/zh/getting-started/tutorials/local_setup.html)
