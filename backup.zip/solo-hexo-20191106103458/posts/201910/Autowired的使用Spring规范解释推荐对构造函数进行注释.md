title: Autowired的使用--Spring规范解释，推荐对构造函数进行注释
date: '2019-10-10 17:07:33'
updated: '2019-10-10 17:07:33'
tags: [java]
permalink: /articles/2019/10/10/1570698452955.html
---
[https://cloud.tencent.com/developer/article/1333064](https://cloud.tencent.com/developer/article/1333064)

1. 在编写代码的时候，使用@Autowired注解是，发现IDE报的一个警告，如下：

* Spring Team recommends "Always use constructor based dependency injection in your beans. Always use assertions for mandatory dependencies.

* 翻译： Spring建议，总是在您的bean中使用构造函数建立依赖注入。总是使用断言强制依赖,那么是为什么呢？

2. 我们可以理一下java的基础点，不考虑父类，初始化的顺序

* 静态变量或静态语句块–>实例变量或初始化语句块–>构造方法–>@Autowired

* ps.静态变量或静态语句块的初始化顺序是自上到下的顺序，被老大问到了... 

3. 好的，有了上面的铺垫，我们来看看下面的代码。

* @Autowiredprivate User user;private School school;public UserServiceImpl(){    this.school.id = user.getSchoolId();}

* 由于java先执行构造方法，导致 this.school = user.getSchool();

  报空指针异常（虽然这个例子正常人都不会这样写)...  解决办法就是  使用构造器注入了

* private User user;private String schoolId;@Autowiredpublic UserServiceImpl(User user){    this.user = user;    this.schoolId = user.getSchoolId();}

4. 而且若是你是个单例的模式（bean没写@scope，默认为单例，

   那么spring还建议你在bean的声明上加final，这个的解析就简单粗暴了

* 因为加上final只会在程序启动的时候初始化一次，并且在程序运行的时候不会再改变。

### 官方的建议例子

   *  private final EnterpriseDbService service;    @Autowired    public EnterpriseDbController(EnterpriseDbService service) {       this.service = service;    }
