title: clickhouse按月删除数据
date: '2019-08-23 15:16:31'
updated: '2019-08-23 15:16:44'
tags: [clickhouse]
permalink: /articles/2019/08/23/1566544591583.html
---
按月删除, testdb是库名，testtable是表名
```
ALTER TABLE testdb.testtable DROP PARTITION '201907'
```
