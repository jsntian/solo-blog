title: 阿里云centos配置ssh和主机名脚本
date: '2019-08-15 10:46:33'
updated: '2019-08-27 12:26:56'
tags: [阿里云, shell, 运维]
permalink: /centos-shell
---
# 1. 建议使用密钥对登录，提高安全性
    chmod 400 test.pem
    ssh -p5678 -i ~/.ssh/test.pem root@xx.xx.xx.xx

# 2. 更改ssh默认端口号，不要用原先的22端口
```
sudo sed -i "s/#Port 22/Port 5678/g" /etc/ssh/sshd_config
sudo sed -i "s/#LoginGraceTime 2m/LoginGraceTime 30/g" /etc/ssh/sshd_config
sudo sed -i "s/#MaxAuthTries 6/MaxAuthTries 3/g" /etc/ssh/sshd_config
sudo echo -e 'Protocol 2' >> /etc/ssh/sshd_config
sudo service sshd restart
```
  - LoginGraceTime 允许一次登录花费 30 秒；如果用户花费的时间超过 30 秒，就不允许他访问，必须重新登录
  - MaxAuthTries 把错误尝试的次数限制为 3 次，3 次之后拒绝登录尝试
  - Protocol 2 行禁止使用比较弱的协议
# 3. 修改主机名,ssh登录后命令行最左边显示的名称
  ```
sudo hostnamectl set-hostname XXX(此处是主机名)
```

