title: nginx.conf之https ssl配置
date: '2019-08-22 19:09:14'
updated: '2019-08-22 19:11:44'
tags: [nginx, 运维, shell, 阿里云]
permalink: /articles/2019/08/22/1566472154626.html
---
1. 腾讯云或阿里云申请ssl证书，免费的一年得到如下文件
    - xxxxx_www.test.com.key
    - xxxxx_www.test.com.pem
2. 服务器上创建ssl证书存放目录
  ```
mkdir -p /usr/local/nginx/conf/ssl
```

3.上传证书
```
scp -r -P 5678 -i ~/.ssh/test.pem  ~/xxxxx_www.test.com.key root@xx.xx.xx.xx:/usr/local/nginx/conf/ssl
scp -r -P 5678 -i ~/.ssh/test.pem  ~/xxxxx_www.test.com.pem root@xx.xx.xx.xx:/usr/local/nginx/conf/ssl
```
4.配置nginx,服务器上/usr/local/nginx/conf/vhosts目录下创建域名配置 文件www.test.com,
```
cd /usr/local/nginx/conf/vhosts
vim www.test.com
```

编辑内容如下

 ```
server {
    listen 80;
    server_name www.test.com;
    rewrite ^(.*) https://$server_name$1 permanent;
}
server {
        listen       443 ssl;
        server_name  www.test.com;
        ssl          on;
        ssl_certificate      /usr/local/nginx/conf/ssl/xxxxx_www.test.com.pem;
        ssl_certificate_key  /usr/local/nginx/conf/ssl/xxxxx_www.test.com.key;
        ssl_session_timeout  5m;
        location / {
            proxy_set_header  X-Forwarded-For $remote_addr;
            proxy_set_header  X-Forwarded-Host $server_name;
            proxy_set_header Host $host;
            proxy_pass http://127.0.0.1:8080;
        }
    }
```

