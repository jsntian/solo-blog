title: centos安装配置jdk
date: '2019-08-22 15:51:22'
updated: '2019-08-22 17:03:25'
tags: [阿里云, shell, 运维, jdk]
permalink: /articles/2019/08/22/1566460282263.html
---
1. 下载
    打开https://www.oracle.com/technetwork/java/javase/downloads/index.html ,找到最下面的 Java Archive 点进去进入历史版本列表，或在我的百度网盘下载 jdk-8u131-linux-x64.tar.gz：链接: https://pan.baidu.com/s/1aRESQ9elqEtZrqwY1cariA 提取码: 5m8j
 
2. 上传服务器并安装配置
  ```
##本地上传
 scp -r -P 5678 -i ~/.ssh/gsssp.pem ~/jdk-8u131-linux-x64.tar.gz root@xx.xx.xx.xx:~
 ##登上服务器执行以下
  mkdir -p /usr/java
  cd ~
  tar -zxvf jdk-8u131-linux-x64.tar.gz -C /usr/java 
  sudo echo -e 'export JAVA_HOME=/usr/java/jdk1.8.0_131' >> /etc/profile
  sudo echo -e 'export CLASSPATH=.:/lib/dt.jar:/lib/tools.jar:/lib:/lib:' >> /etc/profile
  sudo echo -e 'export PATH=$JAVA_HOME/bin:$PATH' >> /etc/profile
  source /etc/profile
  java -version
```

