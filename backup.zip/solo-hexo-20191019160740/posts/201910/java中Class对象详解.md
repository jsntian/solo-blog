title: java中Class对象详解
date: '2019-10-08 21:50:48'
updated: '2019-10-08 21:50:48'
tags: [Java核心要义]
permalink: /articles/2019/10/08/1570542648201.html
---
 java中把生成Class对象和实例对象弄混了，更何况生成Class对象和生成instance都有多种方式。所以只有弄清其中的原理，才可以深入理解。首先要生成Class对象，然后再生成Instance。那Class对象的生成方式有哪些呢，以及其中是如何秘密生成的呢？

Class对象的生成方式如下：

1.Class.forName("类名字符串")  （注意：类名字符串必须是全称，包名+类名）

2.类名.class

3.实例对象.getClass()

通过一段小程序，来观察一下Class对象的生成的原理。
​

```java
/**

 * 2012-2-6

 * Administrator

 */

/**

 * @author: 梁焕月 

 * 文件名：TestClass.java 

 * 时间：2012-2-6上午10:01:52  

 */

public class TestClass {

 

public  static void main(String[] args)

{

try {

//测试Class.forName()

Class testTypeForName=Class.forName("TestClassType");        

System.out.println("testForName---"+testTypeForName);

//测试类名.class

Class testTypeClass=TestClassType.class;

System.out.println("testTypeClass---"+testTypeClass);

//测试Object.getClass()

TestClassType testGetClass= new TestClassType();

System.out.println("testGetClass---"+testGetClass.getClass());

 

} catch (ClassNotFoundException e) {

// TODO Auto-generated catch block

e.printStackTrace();

}

 

}

}

 class TestClassType{

//构造函数

public TestClassType(){

System.out.println("----构造函数---");

}

//静态的参数初始化

static{

System.out.println("---静态的参数初始化---");

}

//非静态的参数初始化

{

System.out.println("----非静态的参数初始化---");

}        

}

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

​  

测试的结果如下：

---静态的参数初始化---

testForName---class TestClassType

testTypeClass---class TestClassType

----非静态的参数初始化---

----构造函数---

testGetClass---class TestClassType

  

根据结果可以发现，三种生成的Class对象一样的。并且三种生成Class对象只打印一次“静态的参数初始化”。 

我们知道，静态的方法属性初始化，是在加载类的时候初始化。而非静态方法属性初始化，是new类实例对象的时候加载。

因此，这段程序说明，三种方式生成Class对象，其实只有一个Class对象。在生成Class对象的时候，首先判断内存中是否已经加载。

所以，生成Class对象的过程其实是如此的：

当我们编写一个新的java类时,JVM就会帮我们编译成class对象,存放在同名的.class文件中。在运行时，当需要生成这个类的对象，JVM就会检查此类是否已经装载内存中。若是没有装载，则把.class文件装入到内存中。若是装载，则根据class文件生成实例对象。

转自：http://blog.csdn.net/yuebinghaoyuan/article/details/7244123
