title: centos下nginx配置安装
date: '2019-08-22 18:25:17'
updated: '2019-08-22 19:14:05'
tags: [shell, 运维, 阿里云, nginx]
permalink: /articles/2019/08/22/1566469517608.html
---
1. 下载安装包并上传到服务器
    - nginx-1.14.2.tar.gz : 百度网盘链接: https://pan.baidu.com/s/17Mu_BFb_0LPLnuG0kRIX7A 提取码: 78ct  
    - ngx_cache_purge-2.3.tar.gz : 链接: https://pan.baidu.com/s/1D7CgyHaSXzyIwAq06IdVDA 提取码: p7ke  
    - nginx.conf 链接: https://pan.baidu.com/s/1zzkQ_hp4spzQnhv_Wwh4iw 提取码: cb7b  
    Nginx自带的缓存模块可以把静态资源缓存到内存中，提高了用户请求静态资源的速度，并且nginx自带缓存模块配置简单，使用灵活，搭配第三方插件可以实现手动清除指定的缓存。ngx_cache_purge就是清除nginx缓存的插件，不需要的话就不用了，另外，在生产环境上我们用过nginx的缓存，总是莫名其妙500或502错误，并发量高的网站不建议使用。
```
  scp -r -i ~/.ssh/test.pem nginx-1.14.2.tar.gz   root@xx.xx.xx.xx:~
  scp -r -i ~/.ssh/test.pem  ngx_cache_purge-2.3.tar.gz   root@xx.xx.xx.xx:~ 
``` 
2. 登上服务器shell脚本安装
  ```
cd ~  
 tar -zxvf nginx-1.14.2.tar.gz   
 tar -zxvf ngx_cache_purge-2.3.tar.gz  
 cd nginx-1.14.2  
 yum -y  install gcc-c++ pcre-devel openssl openssl-devel  
##支持https nginx统计 nginx缓存插件等
 ./configure --prefix=/usr/local/nginx --add-module=../ngx_cache_purge-2.3 --with-http_stub_status_module --with-http_ssl_module  
 make && make install  
##添加个非root用户ecs-nginx,用它启动nginx,增加安全性
 useradd ecs-nginx
```
3. 上传配置文件  
```
scp -r -i ~/.ssh/test.pem nginx.conf    root@xx.xx.xx.xx:/usr/local/nginx/conf/
```

建个vhosts文件夹方便配置多个域名就在conf下

  ```
mkdir -p /usr/local/nginx/conf/vhosts
```

 在vhosts下建文件www.test.com,内容如下

```
server {
        listen       80;
        server_name  www.test.com; 
        location / {
	    proxy_set_header X-Real-IP $remote_addr;
	    proxy_set_header Host $host;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_pass http://xx.xx.xx.xx:8080;
        }
    }
```

